/*
  # Create service requests table

  1. New Tables
    - `service_requests`
      - `id` (uuid, primary key) - Unique identifier for each request
      - `service_type` (text) - Either "plumbing" or "hvac"
      - `first_name` (text) - Customer's first name
      - `phone_number` (text) - Customer's phone number
      - `postal_code` (text) - Customer's postal code
      - `in_service_area` (boolean) - Whether customer is in service area
      - `contact_immediately` (boolean) - Can we contact immediately
      - `is_emergency` (boolean) - Is this an emergency or quote request
      - `is_homeowner` (boolean) - Is the person a homeowner
      - `issue_type` (text) - Selected issue from dropdown
      - `issue_description` (text) - Detailed description of the issue
      - `language` (text) - Language preference (en or fr)
      - `created_at` (timestamptz) - When the request was created
      - `email_sent` (boolean) - Whether confirmation email was sent

  2. Security
    - Enable RLS on `service_requests` table
    - Add policy for inserting service requests (public access for form submissions)
    - Add policy for admin users to read all requests
*/

CREATE TABLE IF NOT EXISTS service_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type text NOT NULL,
  first_name text NOT NULL,
  phone_number text NOT NULL,
  postal_code text NOT NULL,
  in_service_area boolean DEFAULT false,
  contact_immediately boolean DEFAULT false,
  is_emergency boolean DEFAULT false,
  is_homeowner boolean DEFAULT false,
  issue_type text NOT NULL,
  issue_description text DEFAULT '',
  language text DEFAULT 'en',
  created_at timestamptz DEFAULT now(),
  email_sent boolean DEFAULT false
);

ALTER TABLE service_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit service requests"
  ON service_requests
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Service requests are not publicly readable"
  ON service_requests
  FOR SELECT
  TO authenticated
  USING (false);