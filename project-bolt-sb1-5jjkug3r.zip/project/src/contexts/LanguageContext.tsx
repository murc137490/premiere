import { createContext, useContext, useState, ReactNode } from 'react';

type Language = 'en' | 'fr';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const translations = {
  en: {
    siteName: 'Premiere Services',
    tagline: 'Professional Plumbing & HVAC Solutions',
    callNow: 'Call Now for Immediate Service',
    selectService: 'Select Your Service',
    plumbing: 'Plumbing',
    hvac: 'HVAC',
    next: 'Next',
    back: 'Back',
    submit: 'Submit Request',

    contactInfo: 'Contact Information',
    firstName: 'First Name',
    phoneNumber: 'Phone Number',
    postalCode: 'Postal Code',

    serviceArea: 'Service Area Check',
    inServiceArea: 'Great! We service your area.',
    outOfServiceArea: 'Sorry, we do not currently service your area.',

    additionalInfo: 'Additional Information',
    contactImmediately: 'Can we contact you immediately?',
    serviceType: 'Service Type',
    emergency: 'Emergency - Need immediate service',
    quote: 'Quote - Not urgent',
    homeowner: 'Are you the homeowner?',
    yes: 'Yes',
    no: 'No',

    issueDetails: 'Issue Details',
    selectIssue: 'Select the type of issue',
    issueDescription: 'Describe the issue (optional)',
    descriptionPlaceholder: 'Tell us what happened and the current situation...',

    plumbingEmergencyLeak: 'Emergency Leak',
    plumbingDrainClog: 'Drain Clog',
    plumbingWaterHeater: 'Water Heater Issue',
    plumbingInstallation: 'Installation',
    plumbingOther: 'Other',

    hvacFurnaceRepair: 'Furnace Repair',
    hvacACRepair: 'AC Repair',
    hvacInstallation: 'Installation',
    hvacNoHeat: 'No Heat',
    hvacOther: 'Other',

    thankYou: 'Thank You!',
    requestSubmitted: 'Your service request has been submitted successfully.',
    confirmationEmail: 'A confirmation email has been sent to our team.',
    contactSoon: 'We will contact you shortly.',
    newRequest: 'Submit Another Request',

    privacyTitle: 'Privacy Notice',
    privacyText: 'Your information is shared only with local licensed service providers to fulfill your service request. We do not sell your data to third parties.',
    footerConsent: 'By submitting this form, you agree to be contacted by a local licensed contractor regarding your service request.',

    required: 'This field is required',
    invalidPhone: 'Please enter a valid phone number',
    invalidPostal: 'Please enter a valid postal code',
  },
  fr: {
    siteName: 'Services Premiere',
    tagline: 'Solutions Professionnelles de Plomberie et CVC',
    callNow: 'Appelez Maintenant pour un Service Immédiat',
    selectService: 'Sélectionnez Votre Service',
    plumbing: 'Plomberie',
    hvac: 'CVC',
    next: 'Suivant',
    back: 'Retour',
    submit: 'Soumettre la Demande',

    contactInfo: 'Coordonnées',
    firstName: 'Prénom',
    phoneNumber: 'Numéro de Téléphone',
    postalCode: 'Code Postal',

    serviceArea: 'Vérification de la Zone de Service',
    inServiceArea: 'Excellent! Nous desservons votre région.',
    outOfServiceArea: 'Désolé, nous ne desservons pas actuellement votre région.',

    additionalInfo: 'Informations Supplémentaires',
    contactImmediately: 'Pouvons-nous vous contacter immédiatement?',
    serviceType: 'Type de Service',
    emergency: 'Urgence - Besoin de service immédiat',
    quote: 'Soumission - Non urgent',
    homeowner: 'Êtes-vous le propriétaire?',
    yes: 'Oui',
    no: 'Non',

    issueDetails: 'Détails du Problème',
    selectIssue: 'Sélectionnez le type de problème',
    issueDescription: 'Décrivez le problème (optionnel)',
    descriptionPlaceholder: 'Dites-nous ce qui s\'est passé et la situation actuelle...',

    plumbingEmergencyLeak: 'Fuite d\'Urgence',
    plumbingDrainClog: 'Drain Bouché',
    plumbingWaterHeater: 'Problème de Chauffe-eau',
    plumbingInstallation: 'Installation',
    plumbingOther: 'Autre',

    hvacFurnaceRepair: 'Réparation de Fournaise',
    hvacACRepair: 'Réparation de Climatiseur',
    hvacInstallation: 'Installation',
    hvacNoHeat: 'Pas de Chauffage',
    hvacOther: 'Autre',

    thankYou: 'Merci!',
    requestSubmitted: 'Votre demande de service a été soumise avec succès.',
    confirmationEmail: 'Un courriel de confirmation a été envoyé à notre équipe.',
    contactSoon: 'Nous vous contacterons sous peu.',
    newRequest: 'Soumettre une Autre Demande',

    privacyTitle: 'Avis de Confidentialité',
    privacyText: 'Vos informations sont partagées uniquement avec des fournisseurs de services locaux agréés pour répondre à votre demande. Nous ne vendons pas vos données à des tiers.',
    footerConsent: 'En soumettant ce formulaire, vous acceptez d\'être contacté par un entrepreneur local agréé concernant votre demande de service.',

    required: 'Ce champ est obligatoire',
    invalidPhone: 'Veuillez entrer un numéro de téléphone valide',
    invalidPostal: 'Veuillez entrer un code postal valide',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
