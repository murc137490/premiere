export type ServiceType = 'plumbing' | 'hvac' | null;

export type PlumbingIssue =
  | 'plumbingEmergencyLeak'
  | 'plumbingDrainClog'
  | 'plumbingWaterHeater'
  | 'plumbingInstallation'
  | 'plumbingOther';

export type HVACIssue =
  | 'hvacFurnaceRepair'
  | 'hvacACRepair'
  | 'hvacInstallation'
  | 'hvacNoHeat'
  | 'hvacOther';

export interface FormData {
  serviceType: ServiceType;
  firstName: string;
  phoneNumber: string;
  postalCode: string;
  inServiceArea: boolean | null;
  contactImmediately: boolean;
  isEmergency: boolean;
  isHomeowner: boolean;
  issueType: PlumbingIssue | HVACIssue | '';
  issueDescription: string;
}

export interface FormErrors {
  firstName?: string;
  phoneNumber?: string;
  postalCode?: string;
  issueType?: string;
}
