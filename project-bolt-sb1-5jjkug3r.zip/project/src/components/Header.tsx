import { Phone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function Header() {
  const { t, language, setLanguage } = useLanguage();

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">{t('siteName')}</h1>
            <p className="text-sm text-gray-600 mt-1">{t('tagline')}</p>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex gap-2">
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  language === 'en'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('fr')}
                className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                  language === 'fr'
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              >
                FR
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-red-600 to-red-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <a
            href="tel:4505003360"
            className="flex items-center justify-center gap-3 text-white hover:opacity-90 transition-opacity"
          >
            <Phone className="w-5 h-5 animate-pulse" />
            <span className="text-lg sm:text-xl font-bold">{t('callNow')}</span>
            <span className="text-lg sm:text-xl font-bold tracking-wider">450-500-3360</span>
          </a>
        </div>
      </div>
    </header>
  );
}
