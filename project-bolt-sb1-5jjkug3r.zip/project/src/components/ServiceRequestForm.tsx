import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { FormData, FormErrors, ServiceType, PlumbingIssue, HVACIssue } from '../types/form';
import { supabase } from '../lib/supabase';
import { checkServiceArea, validatePostalCode, formatPostalCode } from '../utils/serviceArea';
import { validatePhoneNumber, formatPhoneNumber } from '../utils/validation';
import { CheckCircle } from 'lucide-react';

export function ServiceRequestForm() {
  const { t, language } = useLanguage();
  const [step, setStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errors, setErrors] = useState<FormErrors>({});

  const [formData, setFormData] = useState<FormData>({
    serviceType: null,
    firstName: '',
    phoneNumber: '',
    postalCode: '',
    inServiceArea: null,
    contactImmediately: false,
    isEmergency: false,
    isHomeowner: true,
    issueType: '',
    issueDescription: '',
  });

  const validateStep = (currentStep: number): boolean => {
    const newErrors: FormErrors = {};

    if (currentStep === 2) {
      if (!formData.firstName.trim()) {
        newErrors.firstName = t('required');
      }
      if (!formData.phoneNumber.trim()) {
        newErrors.phoneNumber = t('required');
      } else if (!validatePhoneNumber(formData.phoneNumber)) {
        newErrors.phoneNumber = t('invalidPhone');
      }
      if (!formData.postalCode.trim()) {
        newErrors.postalCode = t('required');
      } else if (!validatePostalCode(formData.postalCode)) {
        newErrors.postalCode = t('invalidPostal');
      }
    }

    if (currentStep === 4) {
      if (!formData.issueType) {
        newErrors.issueType = t('required');
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      if (step === 2) {
        const inArea = checkServiceArea(formData.postalCode);
        setFormData({ ...formData, inServiceArea: inArea });
      }
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    setStep(step - 1);
    setErrors({});
  };

  const handleSubmit = async () => {
    if (!validateStep(4)) return;

    setIsSubmitting(true);

    try {
      const { error } = await supabase.from('service_requests').insert({
        service_type: formData.serviceType,
        first_name: formData.firstName,
        phone_number: formatPhoneNumber(formData.phoneNumber),
        postal_code: formatPostalCode(formData.postalCode),
        in_service_area: formData.inServiceArea,
        contact_immediately: formData.contactImmediately,
        is_emergency: formData.isEmergency,
        is_homeowner: formData.isHomeowner,
        issue_type: formData.issueType,
        issue_description: formData.issueDescription,
        language: language,
      });

      if (error) throw error;

      setIsSubmitted(true);
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleNewRequest = () => {
    setFormData({
      serviceType: null,
      firstName: '',
      phoneNumber: '',
      postalCode: '',
      inServiceArea: null,
      contactImmediately: false,
      isEmergency: false,
      isHomeowner: true,
      issueType: '',
      issueDescription: '',
    });
    setStep(1);
    setIsSubmitted(false);
    setErrors({});
  };

  if (isSubmitted) {
    return (
      <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="flex justify-center mb-6">
          <CheckCircle className="w-20 h-20 text-green-500" />
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-4">{t('thankYou')}</h2>
        <p className="text-lg text-gray-700 mb-2">{t('requestSubmitted')}</p>
        <p className="text-gray-600 mb-6">{t('contactSoon')}</p>
        <button
          onClick={handleNewRequest}
          className="bg-blue-600 text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold"
        >
          {t('newRequest')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-2xl shadow-xl overflow-hidden">
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 px-8 py-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-blue-100 text-sm font-medium mb-1">
              {step === 1 && t('selectService')}
              {step === 2 && t('contactInfo')}
              {step === 3 && t('additionalInfo')}
              {step === 4 && t('issueDetails')}
            </div>
            <div className="flex gap-2">
              {[1, 2, 3, 4].map((s) => (
                <div
                  key={s}
                  className={`h-1.5 rounded-full transition-all ${
                    s <= step ? 'bg-white w-8' : 'bg-blue-400 w-6'
                  }`}
                />
              ))}
            </div>
          </div>
          <div className="text-white text-sm font-medium">
            {step}/4
          </div>
        </div>
      </div>

      <div className="p-8">
        {step === 1 && <Step1 formData={formData} setFormData={setFormData} onNext={handleNext} />}
        {step === 2 && (
          <Step2
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            onNext={handleNext}
            onBack={handleBack}
          />
        )}
        {step === 3 && (
          <Step3 formData={formData} setFormData={setFormData} onNext={handleNext} onBack={handleBack} />
        )}
        {step === 4 && (
          <Step4
            formData={formData}
            setFormData={setFormData}
            errors={errors}
            onSubmit={handleSubmit}
            onBack={handleBack}
            isSubmitting={isSubmitting}
          />
        )}
      </div>
    </div>
  );
}

function Step1({
  formData,
  setFormData,
  onNext,
}: {
  formData: FormData;
  setFormData: (data: FormData) => void;
  onNext: () => void;
}) {
  const { t } = useLanguage();

  const selectService = (service: ServiceType) => {
    setFormData({ ...formData, serviceType: service });
    setTimeout(onNext, 300);
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">{t('selectService')}</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <button
          onClick={() => selectService('plumbing')}
          className="group relative overflow-hidden bg-gradient-to-br from-blue-50 to-blue-100 border-2 border-blue-200 rounded-xl p-8 hover:border-blue-400 hover:shadow-lg transition-all"
        >
          <div className="text-5xl mb-4">🔧</div>
          <h3 className="text-xl font-bold text-gray-900">{t('plumbing')}</h3>
        </button>
        <button
          onClick={() => selectService('hvac')}
          className="group relative overflow-hidden bg-gradient-to-br from-orange-50 to-orange-100 border-2 border-orange-200 rounded-xl p-8 hover:border-orange-400 hover:shadow-lg transition-all"
        >
          <div className="text-5xl mb-4">❄️</div>
          <h3 className="text-xl font-bold text-gray-900">{t('hvac')}</h3>
        </button>
      </div>
    </div>
  );
}

function Step2({
  formData,
  setFormData,
  errors,
  onNext,
  onBack,
}: {
  formData: FormData;
  setFormData: (data: FormData) => void;
  errors: FormErrors;
  onNext: () => void;
  onBack: () => void;
}) {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('contactInfo')}</h2>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">{t('firstName')}</label>
        <input
          type="text"
          value={formData.firstName}
          onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
          className={`w-full px-4 py-3 border ${
            errors.firstName ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
          placeholder="John"
        />
        {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">{t('phoneNumber')}</label>
        <input
          type="tel"
          value={formData.phoneNumber}
          onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
          className={`w-full px-4 py-3 border ${
            errors.phoneNumber ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
          placeholder="(450) 500-3360"
        />
        {errors.phoneNumber && <p className="text-red-500 text-sm mt-1">{errors.phoneNumber}</p>}
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-2">{t('postalCode')}</label>
        <input
          type="text"
          value={formData.postalCode}
          onChange={(e) => setFormData({ ...formData, postalCode: e.target.value.toUpperCase() })}
          className={`w-full px-4 py-3 border ${
            errors.postalCode ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
          placeholder="H1A 1A1"
          maxLength={7}
        />
        {errors.postalCode && <p className="text-red-500 text-sm mt-1">{errors.postalCode}</p>}
      </div>

      <div className="flex gap-3 pt-4">
        <button
          onClick={onBack}
          className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
        >
          {t('back')}
        </button>
        <button
          onClick={onNext}
          className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
        >
          {t('next')}
        </button>
      </div>
    </div>
  );
}

function Step3({
  formData,
  setFormData,
  onNext,
  onBack,
}: {
  formData: FormData;
  setFormData: (data: FormData) => void;
  onNext: () => void;
  onBack: () => void;
}) {
  const { t } = useLanguage();

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('serviceArea')}</h2>
        {formData.inServiceArea ? (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-green-800 font-semibold">{t('inServiceArea')}</p>
          </div>
        ) : (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
            <p className="text-red-800 font-semibold">{t('outOfServiceArea')}</p>
          </div>
        )}
      </div>

      <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('additionalInfo')}</h2>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">
          {t('contactImmediately')}
        </label>
        <div className="flex gap-4">
          <button
            onClick={() => setFormData({ ...formData, contactImmediately: true })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              formData.contactImmediately
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
            }`}
          >
            {t('yes')}
          </button>
          <button
            onClick={() => setFormData({ ...formData, contactImmediately: false })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              !formData.contactImmediately
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
            }`}
          >
            {t('no')}
          </button>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">{t('serviceType')}</label>
        <div className="flex gap-4">
          <button
            onClick={() => setFormData({ ...formData, isEmergency: true })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              formData.isEmergency
                ? 'bg-red-600 text-white border-red-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-red-400'
            }`}
          >
            {t('emergency')}
          </button>
          <button
            onClick={() => setFormData({ ...formData, isEmergency: false })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              !formData.isEmergency
                ? 'bg-green-600 text-white border-green-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-green-400'
            }`}
          >
            {t('quote')}
          </button>
        </div>
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">{t('homeowner')}</label>
        <div className="flex gap-4">
          <button
            onClick={() => setFormData({ ...formData, isHomeowner: true })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              formData.isHomeowner
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
            }`}
          >
            {t('yes')}
          </button>
          <button
            onClick={() => setFormData({ ...formData, isHomeowner: false })}
            className={`flex-1 px-6 py-3 rounded-lg border-2 transition-all font-semibold ${
              !formData.isHomeowner
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-white text-gray-700 border-gray-300 hover:border-blue-400'
            }`}
          >
            {t('no')}
          </button>
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <button
          onClick={onBack}
          className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
        >
          {t('back')}
        </button>
        <button
          onClick={onNext}
          className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold"
        >
          {t('next')}
        </button>
      </div>
    </div>
  );
}

function Step4({
  formData,
  setFormData,
  errors,
  onSubmit,
  onBack,
  isSubmitting,
}: {
  formData: FormData;
  setFormData: (data: FormData) => void;
  errors: FormErrors;
  onSubmit: () => void;
  onBack: () => void;
  isSubmitting: boolean;
}) {
  const { t } = useLanguage();

  const plumbingIssues: PlumbingIssue[] = [
    'plumbingEmergencyLeak',
    'plumbingDrainClog',
    'plumbingWaterHeater',
    'plumbingInstallation',
    'plumbingOther',
  ];

  const hvacIssues: HVACIssue[] = [
    'hvacFurnaceRepair',
    'hvacACRepair',
    'hvacInstallation',
    'hvacNoHeat',
    'hvacOther',
  ];

  const issues = formData.serviceType === 'plumbing' ? plumbingIssues : hvacIssues;

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('issueDetails')}</h2>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">{t('selectIssue')}</label>
        <select
          value={formData.issueType}
          onChange={(e) => setFormData({ ...formData, issueType: e.target.value as PlumbingIssue | HVACIssue })}
          className={`w-full px-4 py-3 border ${
            errors.issueType ? 'border-red-500' : 'border-gray-300'
          } rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all`}
        >
          <option value="">{t('selectIssue')}</option>
          {issues.map((issue) => (
            <option key={issue} value={issue}>
              {t(issue)}
            </option>
          ))}
        </select>
        {errors.issueType && <p className="text-red-500 text-sm mt-1">{errors.issueType}</p>}
      </div>

      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-3">
          {t('issueDescription')}
        </label>
        <textarea
          value={formData.issueDescription}
          onChange={(e) => setFormData({ ...formData, issueDescription: e.target.value })}
          rows={5}
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all resize-none"
          placeholder={t('descriptionPlaceholder')}
        />
      </div>

      <div className="flex gap-3 pt-4">
        <button
          onClick={onBack}
          className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors font-semibold"
          disabled={isSubmitting}
        >
          {t('back')}
        </button>
        <button
          onClick={onSubmit}
          disabled={isSubmitting}
          className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? '...' : t('submit')}
        </button>
      </div>
    </div>
  );
}
