import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { ServiceRequestForm } from './components/ServiceRequestForm';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex flex-col">
      <Header />

      <main className="flex-grow py-12 px-4 sm:px-6 lg:px-8">
        <ServiceRequestForm />
      </main>

      <Footer />
    </div>
  );
}

export default App;
